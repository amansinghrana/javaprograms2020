package demo;

public class demo {
    public static void main(String[] args)
    {
        System.out.println("hello world");
    }
}

class testanotherclass
{}
