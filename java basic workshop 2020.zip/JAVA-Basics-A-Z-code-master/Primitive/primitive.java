package Primitive;

public class primitive {
    public static void main(String args[]) {
        byte bytevar=20;
        System.out.println(bytevar);
       //bytevar=130;
        short shortvar=1000;
        System.out.println(shortvar);
       // shortvar=100000;
        int intvar=1200000000;
        System.out.println(intvar);
       // int intvar=12000000000;

        long longvar=120000000000000000L;
        System.out.println(longvar);

        float floatvar=10.345F;
        System.out.println(floatvar);

        double doublevar=1000000000.345678;
        System.out.println(doublevar);

        char varchar=(char)97;
        System.out.println(varchar);



    }

}
