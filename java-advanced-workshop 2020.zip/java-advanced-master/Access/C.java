package Access;

public class C {
    protected void msg(){System.out.println("Hello");}
}
