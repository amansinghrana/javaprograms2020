package Access;
import pack.*;
public class Default {
    public static void main(String args[]){
        A obj = new A();//Compile Time Error
       // obj.msg();//Compile Time Error
    }
}
