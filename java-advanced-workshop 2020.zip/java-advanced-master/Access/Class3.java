package Access;

public class Class3 {
    public static void main(String[]args) {
        student stu = new student();
        stu.setName("mark");
        System.out.println(stu.getName());
    }
}
