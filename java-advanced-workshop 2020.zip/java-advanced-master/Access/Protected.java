package Access;
//import pack.*;
class Protected extends C {
    public static void main(String args[]){
        C obj = new C();
        obj.msg();
    }


}
