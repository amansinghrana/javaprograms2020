package object;

public class constructor {
    public static void main(String args[])
    {
        cube Cube=new cube();
        cube cube2=new cube(10,20,30);//constructor overloading
    }
}
