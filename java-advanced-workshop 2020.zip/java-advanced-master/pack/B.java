package pack;

public class B {
    protected void msg(){System.out.println("Hello");}
}
