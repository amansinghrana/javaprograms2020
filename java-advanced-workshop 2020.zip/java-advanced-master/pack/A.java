package pack;

public class A {
    void msg(){System.out.println("Hello");}

}
