package Oops;//main outside the class

public class CLASS {
    public static void main(String args[]){
        //Creating an object or instance
        student s1=new student();//creating an object of Student
        //Printing values of the object
        System.out.println(s1.id);//accessing member through reference variable
        System.out.println(s1.name);
    }
}
